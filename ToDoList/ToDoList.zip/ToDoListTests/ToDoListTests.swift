//
//  ToDoListTests.swift
//  ToDoListTests
//
//  Created by Kshrugal Reddy Jangalapalli on 11/3/24.
//

import Testing
@testable import ToDoList

struct ToDoListTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
