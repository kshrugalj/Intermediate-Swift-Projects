//
//  Rock_Paper_ScissorsTests.swift
//  Rock_Paper_ScissorsTests
//
//  Created by Kshrugal Reddy Jangalapalli on 11/30/24.
//

import Testing
@testable import Rock_Paper_Scissors

struct Rock_Paper_ScissorsTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
