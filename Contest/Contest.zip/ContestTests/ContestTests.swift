//
//  ContestTests.swift
//  ContestTests
//
//  Created by Kshrugal Reddy Jangalapalli on 11/12/24.
//

import Testing
@testable import Contest

struct ContestTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
