//
//  LeaderboardHabitCollectionViewCell.swift
//  Habits
//
//  Created by Kshrugal Reddy Jangalapalli on 12/6/24.
//
import UIKit

class LeaderboardHabitCollectionViewCell: UICollectionViewCell {
    @IBOutlet var habitNameLabel: UILabel!
    @IBOutlet var leaderLabel: UILabel!
    @IBOutlet var secondaryLabel: UILabel!
}

