//
//  RestarauntTests.swift
//  RestarauntTests
//
//  Created by Kshrugal Reddy Jangalapalli on 11/16/24.
//

import Testing
@testable import Restaraunt

struct RestarauntTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
