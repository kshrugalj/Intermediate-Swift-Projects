//
//  Category.swift
//  Restaraunt
//
//  Created by Kshrugal Reddy Jangalapalli on 11/16/24.
//
struct Categories: Codable {
    let categories: [String]
}
