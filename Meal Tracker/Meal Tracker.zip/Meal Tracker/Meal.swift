//
//  Meal.swift
//  Meal Tracker
//
//  Created by Kshrugal Reddy Jangalapalli on 10/27/24.
//
struct Meal {
    let name: String
    let food : [Food]
}
