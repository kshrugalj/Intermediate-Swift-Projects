//
//  Food.swift
//  Meal Tracker
//
//  Created by Kshrugal Reddy Jangalapalli on 10/27/24.
//

struct Food{
    let name: String
    let description: String
}
