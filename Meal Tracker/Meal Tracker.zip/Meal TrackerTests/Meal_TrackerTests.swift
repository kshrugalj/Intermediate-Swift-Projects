//
//  Meal_TrackerTests.swift
//  Meal TrackerTests
//
//  Created by Kshrugal Reddy Jangalapalli on 10/27/24.
//

import Testing
@testable import Meal_Tracker

struct Meal_TrackerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
